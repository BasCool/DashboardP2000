!!!Start the Dashboard by opening open.bat!!!

Our dashboard delivers the tweets to the dashboard in two different lists, and there is
room to add the filter function.
The filter front end is finished and delivers a 'settings json' to the python script.
So the only two things left to do is:
1. make a filter function that takes the settings json and delivers true if it should
   be placed and false if not.

2. Make a nice design, finishing the website and making it look nice